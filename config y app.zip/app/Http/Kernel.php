<?php
protected $routeMiddleware = [
    // Otros middlewares
    // Eliminar o comentar la siguiente línea:
    // 'admin' => \App\Http\Middleware\AdminMiddleware::class,
];
