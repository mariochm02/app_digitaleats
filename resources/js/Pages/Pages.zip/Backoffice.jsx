import React from 'react';
import { Head } from '@inertiajs/react';

export default function Backoffice() {
    return (
        <div>
            <Head title="Backoffice" />
            <h1>Hola Backoffice</h1>
        </div>
    );
}
